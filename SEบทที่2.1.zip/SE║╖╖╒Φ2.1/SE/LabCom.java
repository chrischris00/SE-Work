public class LabCom{
  static public int roomID;
  public LabCom(int roomID){
    this.roomID=roomID;
  }
  public int showID(){
    return roomID;
  }
}
