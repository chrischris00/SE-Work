public class Admin extends People {
  public Admin(String name){
    super(name);
  }
}
