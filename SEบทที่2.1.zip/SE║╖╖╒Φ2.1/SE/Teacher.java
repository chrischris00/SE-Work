public class Teacher extends People {
  public Teacher(String name){
    super(name);
  }
}
